To run:
make APPS='philosophers_dinner hello_usr producer_consumer' debug

Patch aggainst c0b8a2517f80f0667ce23e30b51e39c705807a9b (mem management)
